package com.example.buyermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuyermicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
