package com.example.sellerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellerserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
