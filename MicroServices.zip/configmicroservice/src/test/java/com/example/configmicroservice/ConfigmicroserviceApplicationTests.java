package com.example.configmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigmicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
