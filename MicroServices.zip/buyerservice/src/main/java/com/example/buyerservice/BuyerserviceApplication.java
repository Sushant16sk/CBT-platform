package com.example.buyerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuyerserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuyerserviceApplication.class, args);
    }

}
