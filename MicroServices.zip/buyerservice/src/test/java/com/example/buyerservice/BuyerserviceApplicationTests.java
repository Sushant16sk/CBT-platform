package com.example.buyerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuyerserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
